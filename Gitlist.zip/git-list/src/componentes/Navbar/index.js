import React from 'react';
import './style.scss';

function Navbar() {
  return (
    <div className="box-nav">
     <div className="list-git">
         <p>Project</p>
     </div>
     <div className="list-git">
         <p>Private</p>
     </div>
     <div className="list-git">
         <p>Url</p>
     </div>
     <div className="list-git">
         <p>Description</p>
     </div>
     <div className="list-git">
         <p>Language</p>
     </div>
    </div>
  );
}

export default Navbar;