import React from 'react';
import './style.scss';

function Search() {
  return (
    <div className="home">
      <div className="box-search">
      <p className="title-wan">Search for a github user account</p>
      <input className="search-lup" type="search"></input>
      <button className="btn-search">Search</button>
      </div>
    </div>
  );
}

export default Search;