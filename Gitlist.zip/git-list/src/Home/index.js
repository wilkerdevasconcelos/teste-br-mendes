import React from 'react';
import Search from'../componentes/Search/index.js';
import Navbar from'../componentes/Navbar/index.js';


function Home() {
  return (
    <div className="home">
     <Search />
     <Navbar />
    </div>
  );
}

export default Home;
